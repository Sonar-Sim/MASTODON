function Map = ReadReflMap(MapFile)
    fid = fopen(MapFile);

    % fscanf keeps grabbing the 0 from the next line
    s = fgetl(fid);
    num = sscanf(s, '%d');
    Map.nx = num(1);
    Map.ny = num(2);

    s = fgetl(fid);
    xvals = sscanf(s, '%e');
    s = fgetl(fid);
    yvals = sscanf(s, '%e');

    Map.xmin = xvals(1);
    Map.dx = xvals(2);

    Map.ymin = yvals(1);
    Map.dy = yvals(2);

    Map.xmax = Map.xmin + Map.dx*(Map.nx-1);
    Map.ymax = Map.ymin + Map.dy*(Map.ny-1);

    % Reads in all of the data. Could use dlmread instead.
    Map.data = fscanf(fid, '%e');

    fclose(fid);

    Map.data = reshape(Map.data, [Map.nx, Map.ny]);
    Map.data = Map.data';
    Map.x = Map.xmin:Map.dx:Map.xmax;
    Map.y = Map.ymin:Map.dy:Map.ymax;
