function [x,y,H] = ReadHeightMapHdf5(filename)
    id = h5read(filename, "/ID");
    if id ~= "MASTODON Simple Bathymetry"
        error("Invalid height map HDF5 file. ID is incorrect.");
    end
    
    x = h5read(filename, "/xcoords");
    y = h5read(filename, "/ycoords");
    H = h5read(filename, "/heights");

    return;
