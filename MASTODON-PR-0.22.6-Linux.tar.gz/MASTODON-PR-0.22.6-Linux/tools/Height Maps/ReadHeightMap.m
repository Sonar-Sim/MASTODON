function [x,y,H] = ReadHeightMap(filename)
    [~,~,ext] = fileparts(filename);
    if (lower(ext) == ".txt")
        [x,y,H] = ReadHeightMapTxt(filename);
    elseif (lower(ext) == ".hdf5" || lower(ext) == ".h5")
        [x,y,H] = ReadHeightMapHdf5(filename);
    else
        error("Unrecognized file format");
    end
    
    return;
