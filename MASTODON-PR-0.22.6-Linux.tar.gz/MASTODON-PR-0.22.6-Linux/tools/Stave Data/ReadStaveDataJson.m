function stave = ReadStaveDataJson(filename)
    stave = jsondecode(fileread(filename));

    stave.nTime = stave.signal.num_samples;
    stave.nElem = stave.sonars.receiver.nelem;
    stave.nPings = stave.vehicle.num_pings;
    stave.Fc = stave.sonars.projector.frequency;
    stave.BW = stave.sonars.projector.bandwidth;
    stave.Fs = stave.signal.fs;
    stave.dy = stave.vehicle.dping;
    stave.rMin = stave.signal.rangemin;
    stave.c = stave.environment.soundspeed;
    stave.SignalApplied = stave.signal.signal_applied;
    stave.bBasebanded = stave.signal.basebanded;
    stave.proj_width = stave.sonars.projector.width;
    stave.recv_width = stave.sonars.receiver.width;
    if isfield(stave.sonars.receiver, "hor_spacing")
        stave.hor_spacing = stave.sonars.receiver.hor_spacing;
    else
        stave.hor_spacing = stave.recv_width;
    end

    if isfield(stave.sonars.receiver, "nelem_hor")
        stave.nElemHor = stave.sonars.receiver.nelem_hor;
    end
    if isfield(stave.sonars.receiver, "nelem_ver")
        stave.nElemVer = stave.sonars.receiver.nelem_ver;
    end
    
    if stave.SignalApplied
        stave.pulse_length = stave.signal.pulse_length;
        signal = stave.signal.signal;
        stave.signal.signal = complex(signal(1:2:end), signal(2:2:end));
    end

    % Older JSON files used this format
    %data = stave.data;
    %data = complex(data(1:2:end), data(2:2:end));
    %data = reshape(data,[stave.nTime, stave.nPings*stave.nElem]);
    %stave.data = data.';
    
    if (isfield(stave.signal, "data_format"))
        if (stave.signal.data_format == "real")
            % Data only has a real part - use as is
        elseif (stave.signal.data_format == "complex")
            % Data is interleaved real/imaginary doubles - convert to complex
            stave.data = complex(stave.data(:,1:2:end), stave.data(:,2:2:end));
        else
            error("Invalid data format key");
        end
    else
        % Assume data is complex
        stave.signal.data_format = "complex";
        stave.data = complex(stave.data(:,1:2:end), stave.data(:,2:2:end));
    end
    
    if isfield(stave, "motion")
        for n = 1:size(stave.motion,1)
            m(n).x = stave.motion(n,1);
            m(n).y = stave.motion(n,2);
            m(n).z = stave.motion(n,3);
            m(n).roll = stave.motion(n,4);
            m(n).pitch = stave.motion(n,5);
            m(n).yaw = stave.motion(n,6);
            m(n).speed = stave.motion(n,7);
            m(n).time = stave.motion(n,8);
        end
        stave.motion = m;
    end
        
%     data = dlmread(filename);
%     
%     stave.nElem = data(2,1);
%     stave.nTime = data(3,1);
%     stave.nPings = data(4,1);
%     stave.Fc = data(5,1);
%     stave.BW = data(6,1);
%     stave.Fs = data(7,1);
%     stave.dy = data(8,1);
%     stave.rMin = data(9,1);
%     
%     data = data(10:end,:);    
%     data = complex(data(:,1), data(:,2));
% 
%     % This allows us to beamform with incomplete data
%     data1 = zeros(stave.nPings*stave.nElem*stave.nTime,1);
%     if length(data) ~= stave.nPings*stave.nElem*stave.nTime
%         disp('Using incomplete stave data file!');
%         data1(1:length(data)) = data;
%         data = data1;
%     end    
%     
%     data = reshape(data,[stave.nTime, stave.nPings*stave.nElem]);
%     stave.data = data.';
%     