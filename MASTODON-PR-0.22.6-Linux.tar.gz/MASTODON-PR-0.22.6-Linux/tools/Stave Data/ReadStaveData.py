import json
import numpy as np


def ReadStaveData(filename):
    with open(filename, 'r') as json_file:
        stave = json.load(json_file)

    data = stave['data']
    data = np.array(data)

    try:
        data_format = stave['signal']['data_format']
        if data_format == "real":
            # Data only has a real part - use as is
            pass
        elif data_format == "complex":
            # Data is interleaved real/imaginary doubles - convert to complex
            data = data[:, 0::2] + 1j * data[:, 1::2]
        else:
            print("Invalid data format key")
            raise KeyError
    except KeyError:
        # The data is interleaved complex
        data = data[:, 0::2] + 1j * data[:, 1::2]
        stave['signal']['data_format'] = "complex"
        
    return data
