function stave = ReadStaveDataHdf5(filename)
    % Test whether this is actually a beamformed data file. It's easy to
    % get the two mixed up.
    bTestBF = false;
    try
        testBF = h5read(filename, "/Sonar/Sensor1/Data1/x_coords");
        % This call just jumps into the catch!
        %error("The input file appears to be a beamformed data file, not a stave data file.");
        bTestBF = true;
    catch
    end
    if bTestBF
        error("The input file appears to be a beamformed data file, not a stave data file.");
    end

    % Test whether this is a likely NGCSD file
    bNgcsd = false;
    try
        h5readatt(filename, "/PlatformMountingInfo", "NominalMountingRollOffsetRad");
        h5readatt(filename, "/SystemHeader", "ElemLengthM");
        try
            stave = ReadStaveDataNgcsd(filename);
        catch
            disp("NGCSD files not supported");
            bNgcsd = false;
            return;
        end
        bNgcsd = true;
    catch
    end

    if bNgcsd
        return;
    end

    stave.nTime = double(h5read(filename, "/signal/num_samples"));
    stave.nElem = double(h5read(filename, "/sonars/receiver/nelem"));

    try
        stave.nElemHor = double(h5read(filename, "/sonars/receiver/nelem_hor"));
    catch
        stave.nElemHor = 1;
    end
    
    try
        stave.nElemVer = double(h5read(filename, "/sonars/receiver/nelem_ver"));
    catch
        stave.nElemVer = 1;
    end
    stave.nPings = double(h5read(filename, "/vehicle/num_pings"));
    stave.Fc = h5read(filename, "/sonars/projector/frequency");
    stave.BW = h5read(filename, "/sonars/projector/bandwidth");
    stave.Fs = h5read(filename, "/signal/fs");
    stave.decimation = h5read(filename, "/signal/decimation");
    stave.dy = h5read(filename, "/vehicle/dping");
    stave.rMin = h5read(filename, "/signal/rangemin");
    stave.c = h5read(filename, "/environment/soundspeed");
    stave.SignalApplied = h5read(filename, "/signal/signal_applied");
    stave.bBasebanded = h5read(filename, "/signal/basebanded");
    stave.proj_width = h5read(filename, "/sonars/projector/width");
    stave.recv_width = h5read(filename, "/sonars/receiver/width");
    % These two are deprecated, and stave.proj.* should be used instead
    stave.proj_height = h5read(filename, "/sonars/projector/height");
    stave.recv_height = h5read(filename, "/sonars/receiver/height");
    
    % These don't exist in older HDF5 files
    try
        stave.proj.height = stave.proj_height;
        stave.recv.height = stave.recv_height;
        stave.proj.bearing = h5read(filename, "/sonars/projector/bearing");
        stave.recv.bearing = h5read(filename, "/sonars/receiver/bearing");
        stave.proj.depression = h5read(filename, "/sonars/projector/depression");
        stave.recv.depression = h5read(filename, "/sonars/receiver/depression");

        stave.veh_altitude = h5read(filename, "/vehicle/altitude");
        stave.water_depth = h5read(filename, "/environment/waterdepth");
    catch
    end

    try
        stave.proj.positions = h5read(filename, "/sonars/projector/positions");
        stave.recv.positions = h5read(filename, "/sonars/receiver/positions");
    catch
        % @todo: If positions are not specified, we should provide
        % positions here based on the parameters above.
    end
    
    try
        stave.hor_spacing = double(h5read(filename, "/sonars/receiver/hor_spacing"));
    catch
        stave.hor_spacing = stave.recv_width;
    end
    
    % Added 2022-AUG-31. Gives the positions of each element at every ping or navigation sample
    try
        srcpos = h5read(filename, "/vehicle/source_positions");
        stave.proj.pos.world = srcpos(:, 2:end);
        stave.proj.pos.time = srcpos(:, 1);
        rcvpos = h5read(filename, "/vehicle/receiver_positions");
        stave.recv.pos.world = rcvpos(:, 2:end);
        stave.recv.pos.time = rcvpos(:, 1);
    catch
    end
    

    % This is an optional field
    try
        stave.overlap = double(h5read(filename, "/vehicle/sas_overlap"));
    catch
    end
    
    if stave.SignalApplied
        stave.signal.times = h5read(filename, "/signal/times");
        stave.signal.signal = h5read(filename, "/signal/signal");
        stave.signal.pulse_length = h5read(filename, "/signal/pulse_length");
        signal = stave.signal.signal;
        stave.signal.signal = complex(signal.re, signal.im);
    end

    % Data is separate real/imaginary doubles - convert to complex
    stave.data = h5read(filename, "/data");
    
    try
        stave.signal.data_format = h5read(filename, "/stave/signal/data_format");
        if (stave.signal.data_format == "real")
            % Data only has a real part - use as is?
            error("Real data in HDF5 has not be tested");
        elseif (stave.signal.data_format == "complex")
            % Data is interleaved real/imaginary doubles - convert to complex
            stave.data = complex(stave.data.re, stave.data.im);
        else
            error("Invalid data format key");
        end
    catch
        % Older formats do not have the data_format dataset, so assume complex.
        stave.signal.data_format = "complex";
        stave.data = complex(stave.data.re, stave.data.im);
    end
    
    motion = h5read(filename, "/vehicle/motion");
    for n = 1:length(motion.time)
        m(n).time = motion.time(n);
        m(n).x = motion.x(n);
        m(n).y = motion.y(n);
        m(n).z = motion.z(n);
        m(n).roll = motion.roll(n);
        m(n).pitch = motion.pitch(n);
        m(n).yaw = motion.yaw(n);
        m(n).speed = motion.speed(n);
    end
    stave.motion = m;
    stave.motion2 = motion;

    motion_world = h5read(filename, "/vehicle/motion_world");
    for n = 1:length(motion_world.time)
        mw(n).time = motion_world.time(n);
        mw(n).latitude = motion_world.latitude(n);
        mw(n).longitude = motion_world.longitude(n);
        mw(n).depth = motion_world.depth(n);
        mw(n).altitude = motion_world.altitude(n);
        mw(n).roll = motion_world.roll(n);
        mw(n).pitch = motion_world.pitch(n);
        mw(n).heading = motion_world.heading(n);
        mw(n).speed = motion_world.speed(n);
    end
    stave.motion_world = mw;
    stave.motion_world2 = motion_world;

    % This doesn't exist in older HDF5 files
    try
        stave.navigation = h5read(filename, "/vehicle/navigation");
    end

    return;
