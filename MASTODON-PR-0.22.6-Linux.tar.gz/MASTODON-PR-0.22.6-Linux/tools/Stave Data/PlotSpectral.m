function PlotSpectral(filename)
    addpath('../General Sonar Tools');

    s = ReadStaveData(filename);

    if s.bBasebanded
        Fc = 0;
    else
        Fc = s.Fc;
    end
    
    PlotSpectrum(s.data, s.Fs, Fc, s.BW);
    
%     L = s.nTime;
%     f = s.Fs * (-L/2+1:(L/2))/L;
%     %data = conj(s.data);
%     data = s.data;
%     spectrum = abs(fftshift(fft(data,[],2)));
%     
%     if s.bBasebanded
%         Fc = 0;
%     else
%         Fc = s.Fc;
%     end
%     BW = s.BW;
%     
%     figure;
%     plot(f,sum(abs(spectrum)));
%     xline(Fc-BW/2, 'r');
%     xline(Fc+BW/2, 'r');
%     xlabel('Frequency (Hz)');
    
