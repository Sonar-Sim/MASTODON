function PlotStaveData(filename)
    s = ReadStaveData(filename);
    
    yMax = s.dy * s.nPings / 2;
    yMin = -yMax;
    y = linspace(yMin, yMax, s.nPings);
    dt = 1.0 / s.Fs;
    dx = s.c * dt;
    x = linspace(s.rMin, s.rMin + dx*s.nTime, s.nTime);
    x = x / 2;  % Two-way travel time
    
    figure;
    %imagesc(x, y, log10(abs(s.data)));
    imagesc(x, y, abs(s.data));
    title('MASTODON - Stave Data Magnitude');
    set(gca, 'YDir', 'normal');
    xlabel('Range (m)');
    colorbar;
    colormap pink;
    
    if s.signal.data_format == "complex"
        figure;
        imagesc(x, y, angle(s.data));
        title('MASTODON - Stave Data Phase');
        set(gca, 'YDir', 'normal');
        xlabel('Range (m)');
        colorbar;
    end
