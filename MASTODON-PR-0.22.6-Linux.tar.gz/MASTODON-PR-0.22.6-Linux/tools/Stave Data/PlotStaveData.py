import sys
import json
import numpy as np
import matplotlib.pyplot as plt
from ReadStaveData import ReadStaveData


# From https://moonbooks.org/Articles/How-to-change-imshow-aspect-ratio-in-matplotlib-/
def forceAspect(ax,aspect):
    im = ax.get_images()
    extent =  im[0].get_extent()
    ax.set_aspect(abs((extent[1]-extent[0])/(extent[3]-extent[2]))/aspect)

if len(sys.argv) == 1:
    #print('Must specify stave data .json file on command line')
    #exit()
    import tkinter as tk
    from tkinter import filedialog

    root = tk.Tk()
    root.withdraw()

    filename = filedialog.askopenfilename()
else:
    filename = sys.argv[1]

#with open(filename, 'r') as json_file:
#    stave = json.load(json_file)
#
#data = stave['data']
#data = np.array(data)

data = ReadStaveData(filename)

#try:
#    data_format = stave['signal']['data_format']
#    if data_format == "real":
#        # Data only has a real part - use as is
#        pass
#    elif data_format == "complex":
#        # Data is interleaved real/imaginary doubles - convert to complex
#        data = data[:, 0::2] + 1j * data[:, 1::2]
#    else:
#        print("Invalid data format key")
#        raise KeyError
#except KeyError:
#    # The data is interleaved complex
#    data = data[:, 0::2] + 1j * data[:, 1::2]
#    stave['signal']['data_format'] = "complex"
#
## data_format is scoped for only the try block
#data_format = stave['signal']['data_format']

#
# Plot magnitude
#
fig = plt.figure()
ax = fig.add_subplot(111)

ax.imshow(abs(data))#, extent=[-1,1,-10,10])
plt.title('Magnitude')
forceAspect(ax,aspect=1.0)
#fig.savefig("magnitude.png", bbox_inches='tight')
plt.show()

#
# Plot phase
#
if data.dtype == np.dtype('complex128'):
    fig = plt.figure()
    ax = fig.add_subplot(111)

    ax.imshow(np.angle(data))#, extent=[-1,1,-10,10])
    plt.title('Phase')
    forceAspect(ax,aspect=1.0)
    #fig.savefig("phase.png", bbox_inches='tight')
    plt.show()
