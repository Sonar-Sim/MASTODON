% Plot the sound velocity/speed profile (SVP/SSP) input file for MASTODON
%  using PC SWAT's input file format (two column text file with
%  depth then speed).
%
% Example usage: PlotSspFile('MunkSSP.txt')
%
function [Depth,SSP] = PlotSspFile(SspFile)
    [Depth,SSP] = ReadSSP(SspFile);
    figure;
    plot(SSP, Depth);
    set(gca, 'Ydir', 'reverse');
    xlabel('Sound speed');
    ylabel('Depth');
    title('Sound speed profile');
end