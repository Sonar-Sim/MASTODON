function [Depth,SSP] = ReadSSP(SSPFile)
    Data = dlmread(SSPFile);
    Depth = Data(:,1);
    SSP = Data(:,2);
    return;
