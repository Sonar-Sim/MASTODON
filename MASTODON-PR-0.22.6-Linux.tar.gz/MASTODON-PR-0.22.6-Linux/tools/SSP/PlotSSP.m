function PlotSSP(Depth, SSP)
    figure;
    %plot(SSP,Depth,'-o','LineWidth',2,'MarkerSize',5,'MarkerEdgeColor','k','MarkerFaceColor','k');
    plot(SSP,Depth,'-o','LineWidth',2,'MarkerSize',2,'MarkerEdgeColor','k','MarkerFaceColor','k');
    set(gca, 'YDir', 'reverse');
    set(gca,'FontSize',16);  % Change axis numbers
    xlabel('Sound speed (m/s)','FontSize',16);
    ylabel('Depth (m)','FontSize',16);
    title('Sound speed profile');
end