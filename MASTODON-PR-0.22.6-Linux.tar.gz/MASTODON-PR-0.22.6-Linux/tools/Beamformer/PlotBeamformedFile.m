function PlotBeamformedFile(filename)
    bf = ReadBeamformed(filename);
    bf.data = abs(bf.data);
    bf.data = bf.data / max(max(bf.data));

    if (bf.beamformer == "phase shift" || bf.beamformer == "MASTODON phase shift")
        PlotBeamformedAngular(bf);
        return;
    end
    
    figure;
    imagesc(bf.x_coords, bf.y_coords, bf.data);

    avg = mean(bf.data, "all");
    sd = std(bf.data, 0, "all");
    scaleMin = 0.0;
    scaleMax = min(1.0, avg + 10 * sd);
    caxis([scaleMin, scaleMax]);
    
    set(gca, 'YDir', 'normal');
    xlabel('Range (m)');
    ylabel('Cross Range (m)');
    title('MASTODON Beamformed Imaging Run');
    colormap pink
    axis image

    return;
