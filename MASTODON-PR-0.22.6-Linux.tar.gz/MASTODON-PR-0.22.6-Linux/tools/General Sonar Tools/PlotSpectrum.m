function PlotSpectrum(data, fs, fc, bw)
    fs = fs / 1000;
    f = linspace(-fs/2, fs/2, length(data));

    if numel(data) == length(data)
        % Case where we just have a 1-D array
        spec = abs(fftshift(fft(data)));
    else
        % Input data is a matrix. Assuming elements x time samples
        nElem = size(data,1);
        nTime = size(data,2);
        spec = zeros(1,nTime);
        for n = 1:nElem
            dataRow = data(n,:);
            spec = spec + abs(fftshift(fft(dataRow)));
        end
        spec = spec / nElem;  % So that we average the spectra
    end
    
    figure;
    plot(f, movmean(spec,10));
    xlabel('Frequency (kHz)');
    ylabel('abs(FFT)');
    
    if nargin > 3
        xline((fc-bw/2)/1000, 'r');
        xline((fc+bw/2)/1000, 'r');
        xline(fc/1000, 'k');
    end
end
