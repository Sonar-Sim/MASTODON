% Calculate the mean squared pressure from an ensemble of pings.
%  Note: The overall scale appears to be off.
function MSP(filename)
    s = ReadStaveData(filename);
    data = abs(s.data).^2;
    mdata = mean(data,1);
    MSP = 10 * log10(mdata);

    t = (0 : length(s.data)-1) / s.Fs;
    c = s.c;  % Speed of sound
    r = c*t / 2;
    
    figure;
    %plot(t, MSP);
    plot(r, MSP);
    %ylim([0 max(max(MSP)) * 1.05]);
    %xlabel('Time (s)');
    xlabel('Range (m)');
    ylabel('Mean squared pressure (dB)');

    return;
