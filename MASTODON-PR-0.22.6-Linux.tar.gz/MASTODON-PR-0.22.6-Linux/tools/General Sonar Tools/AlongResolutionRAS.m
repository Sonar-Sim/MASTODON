% Equation (1.3) of Hawkins's thesis, p. 3
% x = range from the sidescan sonar
% D = aperture length
% f = signal frequency
% alpha = aperture weighting (ex. 0.88 for no/rectangular weighting,
%    1.30 for Hamming weighting)
% c = sound speed
function delta = AlongResolutionRAS(x, D, f, alpha, c)
    if nargin < 4
        c = 1500;
        alpha = 0.88;
    elseif nargin < 5
        c = 1500;
    end
    
    delta = alpha * c * x / (f * D);
    
    return;
