function delta = RangeResolution(BW, alpha, c)
    if nargin < 2
        c = 1500;
        alpha = 0.88;
    elseif nargin < 3
        c = 1500;
    end
    delta = alpha * c / (2 * BW);
    return;
