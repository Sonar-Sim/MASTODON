function eig = ReadEigenrays(Filename)
%ReadEigenrays Returns eigenrays from a file
    data = dlmread(Filename);
    eig.r = data(:,3);
    eig.z = data(:,4);
    eig.s = data(:,5);
    eig.t = data(:,6);
    eig.srcang = data(:,7) * 180 / pi;
    eig.trgang = data(:,8) * 180 / pi;
    eig.nbtm = data(:,9);
    eig.nsrf = data(:,10);
    eig.amp = data(:,11);
    eig.phase = data(:,12);
    eig.spread = data(:,13);
    eig.dphase = data(:,14);
    eig.src = [data(:,15),data(:,16),data(:,17)];