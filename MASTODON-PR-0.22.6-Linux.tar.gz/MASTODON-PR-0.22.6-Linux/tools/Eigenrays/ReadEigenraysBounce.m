function eig = ReadEigenraysBounce(Filename, BtmBounce, SrfBounce)
%ReadEigenraysBounce Returns eigenrays from a file that match a set of
% bottom/surface bounce conditions
    eigOrig = ReadEigenrays(Filename);
    
    toDelete = ~((eigOrig.nbtm == BtmBounce) & (eigOrig.nsrf == SrfBounce));
    
    eig.r = eigOrig.r(~toDelete);
    eig.z = eigOrig.z(~toDelete);
    eig.s = eigOrig.s(~toDelete);
    eig.t = eigOrig.t(~toDelete);
    eig.srcang = eigOrig.srcang(~toDelete);
    eig.trgang = eigOrig.trgang(~toDelete);
    eig.nbtm = eigOrig.nbtm(~toDelete);
    eig.nsrf = eigOrig.nsrf(~toDelete);
    eig.amp = eigOrig.amp(~toDelete);
    eig.phase = eigOrig.phase(~toDelete);
    eig.spread = eigOrig.spread(~toDelete);
    eig.dphase = eigOrig.dphase(~toDelete);
    eig.src = eigOrig.src(~toDelete);