function stave = ReadTimeSeriesHdf5(filename)
    stave.nTime = double(h5read(filename, "/signal/num_samples"));
    stave.nElem = double(h5read(filename, "/sonars/receiver/nelem"));
    stave.Fc = h5read(filename, "/sonars/projector/frequency");
    stave.BW = h5read(filename, "/sonars/projector/bandwidth");
    stave.Fs = h5read(filename, "/signal/fs");
    stave.rMin = h5read(filename, "/signal/rangemin");
    stave.rMax = h5read(filename, "/signal/rangemax");
    stave.c = h5read(filename, "/environment/soundspeed");
    stave.SignalApplied = h5read(filename, "/signal/signal_applied");
    stave.bBasebanded = h5read(filename, "/signal/basebanded");

    stave.proj.width = h5read(filename, "/sonars/projector/width");
    stave.recv.width = h5read(filename, "/sonars/receiver/width");
    stave.proj.height = h5read(filename, "/sonars/projector/height");
    stave.recv.height = h5read(filename, "/sonars/receiver/height");

    stave.proj.bearing = h5read(filename, "/sonars/projector/bearing");
    stave.recv.bearing = h5read(filename, "/sonars/receiver/bearing");
    stave.proj.depression = h5read(filename, "/sonars/projector/depression");
    stave.recv.depression = h5read(filename, "/sonars/receiver/depression");

%    stave.veh_altitude = h5read(filename, "/vehicle/altitude");
    stave.water_depth = h5read(filename, "/environment/waterdepth");

    stave.proj.positions = h5read(filename, "/sonars/projector/positions");
    stave.recv.positions = h5read(filename, "/sonars/receiver/positions");
    
%    stave.hor_spacing = double(h5read(filename, "/sonars/receiver/hor_spacing"));

    stave.nElemHor = double(h5read(filename, "/sonars/receiver/nelem_hor"));
    stave.nElemVer = double(h5read(filename, "/sonars/receiver/nelem_ver"));
    
    if stave.SignalApplied
        stave.signal.times = h5read(filename, "/signal/times");
        stave.signal.signal = h5read(filename, "/signal/signal");
        stave.signal.pulse_length = h5read(filename, "/signal/pulse_length");
        signal = stave.signal.signal;
        stave.signal.signal = complex(signal.re, signal.im);
    end

    % Data is separate real/imaginary doubles - convert to complex
    stave.data = h5read(filename, "/data");
    stave.signal.data_format = "complex";
    stave.data = complex(stave.data.re, stave.data.im);
end
