classdef FltToken < libconf.Token
    methods
        function obj = FltToken(type, text, filename, row, column)
           obj@libconf.Token(type, text, filename, row, column);
           obj.value = str2double(text);
        end
    end
end