classdef Token < matlab.mixin.Heterogeneous
    %TOKEN Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        value
        type
        text
        filename
        row
        column
    end
    
    methods
        function obj = Token(type, text, filename, row, column)
            %TOKEN Construct an instance of this class
            %   Detailed explanation goes here
            obj.type = type;
            obj.text = text;
            obj.filename = filename;
            obj.row = row;
            obj.column = column;
        end
    end
end