classdef Tokenizer < handle
    %TOKENIZER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        filename
        row
        column
    end
    
    methods
        function obj = Tokenizer(filename)
            obj.filename = filename;
            obj.row = 1;
            obj.column = 1;
        end
        
        function tokens = tokenize(obj, input)
            token_map = {        
                {@libconf.FltToken,  libconf.TokenType.float,     '([-+]?(\d+)?\.\d*([eE][-+]?\d+)?)|'}
                {@libconf.FltToken,  libconf.TokenType.float,     '([-+]?(\d+)(\.\d*)?[eE][-+]?\d+)'}
                {@libconf.IntToken,  libconf.TokenType.hex64,     '0[Xx][0-9A-Fa-f]+(L(L)?)'}
                {@libconf.IntToken,  libconf.TokenType.hex,       '0[Xx][0-9A-Fa-f]+'}
                {@libconf.IntToken,  libconf.TokenType.integer64, '[-+]?[0-9]+L(L)?'}
                {@libconf.IntToken,  libconf.TokenType.integer,   '[-+]?[0-9]+'}
                {@libconf.BoolToken, libconf.TokenType.boolean,   '(?i)(true|false)'}
                {@libconf.StrToken,  libconf.TokenType.string,    '"([^"\\]|\\.)*"'}
                {@libconf.Token,     libconf.TokenType.name,      '[A-Za-z\*][-A-Za-z0-9_\*]*'}
                {@libconf.Token,     libconf.TokenType.right_curl,         '\}'}
                {@libconf.Token,     libconf.TokenType.left_curl,         '\{'}
                {@libconf.Token,     libconf.TokenType.right_paren,         '\)'}
                {@libconf.Token,     libconf.TokenType.left_paren,         '\('}
                {@libconf.Token,     libconf.TokenType.right_square,         '\]'}
                {@libconf.Token,     libconf.TokenType.left_square,         '\['}
                {@libconf.Token,     libconf.TokenType.comma,         ','}
                {@libconf.Token,     libconf.TokenType.semicolon,         ';'}
                {@libconf.Token,     libconf.TokenType.equals,         '='}
                {@libconf.Token,     libconf.TokenType.tcolon,         ':'}
            };
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here
            
            % Stripping out comments
            input = regexprep(input,'#[^\n\r]+?(?:\*\)|[\n\r])|\/\/[^\n\r]+?(?:\*\)|[\n\r])|/\*(.|\n)*?\*/','');
            
            tokens = {};
            pos = 1;
            input_size = length(input);
            token_type_count = length(token_map);
            while(pos <= input_size)
                match_start = regexp(input(pos:end),'\s+');
%                 match_start = regexp(input(pos:end),'\s+|#.*[\n\r]+|//.*[\n\r]+');
%                 match_start = regexp(input(pos:end),'#[^\n\r]+?(?:\*\)|[\n\r])');
                if(length(match_start) > 0 && match_start(1) == 1)
                    match_string = regexp(input(pos:end),'\s+','match');
%                     match_string = regexp(input(pos:end),'\s+|#.*[\n\r]+|//.*[\n\r]+','match');
%                     match_string = regexp(input(pos:end),'#[^\n\r]+?(?:\*\)|[\n\r])','match');
                    match_string = match_string{1};
                    pos = pos + length(match_string);
                    continue;
                end
                
                found = false;
                for i = 1:token_type_count
                    match_start = regexp(input(pos:end),token_map{i}{3});
                    if(~isempty(match_start) && match_start(1) == 1)
                        match_string = regexp(input(pos:end),token_map{i}{3},'match');
                        match_string = match_string{1};
                        token = token_map{i}{1}(token_map{i}{2}, match_string, obj.filename, obj.row, obj.column);
                        tokens = [tokens; token];
                        pos = pos + length(match_string);
                        found = true;
                        break;
                    end
                end
                if(found)
                    continue;
                end
            end
        end
    end
end

