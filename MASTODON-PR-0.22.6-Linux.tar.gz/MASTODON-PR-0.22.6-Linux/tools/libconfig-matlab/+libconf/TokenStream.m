classdef TokenStream < handle
    %TOKENSTREAM Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        position
        tokens
    end
    
    methods
        function obj = TokenStream()
            %TOKENSTREAM Construct an instance of this class
            %   Detailed explanation goes here
            obj.position = 1;
            obj.tokens = [];
        end
        
        function from_file(obj,filename)
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here
            lines = '';
            lines = fileread(filename);
%             fid = fopen(filename);
%             while(~feof(fid))
%                 lines = [lines fgetl(fid) newline];
%                 % check for include line here
%             end
%             
%             fclose(fid);
            
            tokenizer = libconf.Tokenizer(filename);
            obj.tokens = [obj.tokens; tokenizer.tokenize(lines);];
        end
        
        function token = peek(obj)
            if(obj.position > length(obj.tokens))
                token = [];
            else
                token = obj.tokens(obj.position);
            end
        end
        
        function token = accept(obj, types)
            token = obj.peek();
            if(~isempty(token))
                for(i = 1:length(types))
                    if(token.type == types(i))
                        obj.position = obj.position + 1;
                        return;
                    end
                end
            end
            token = [];
        end
        
        function token = expect(obj, types)
            token = obj.accept(types);
            if(isempty(token))
                error(['expected ' char(types) ' - got ' obj.tokens(obj.position).text]);
            end
        end
        
        function is_finished = finished(obj)
            is_finished = obj.position > length(obj.tokens);
        end
    end
end

