function TL2D = ReadTL2D(TLFile)
    f = fopen(TLFile);

    Head = fscanf(f, '%d %d');
    TL2D.NumR = Head(1);
    TL2D.NumZ = Head(2);

    fclose(f);

    Data = dlmread(TLFile);
    % Skip header. Cannot specify the skip in dlmread, since it does not like
    % the delimiter being multiple spaces.
    Data = Data(2:end,:);

    TL2D.Ranges = Data(:,1);
    TL2D.Ranges = TL2D.Ranges(1:TL2D.NumZ:end);
    TL2D.Depths = Data(:,2);
    TL2D.Depths = TL2D.Depths(1:TL2D.NumZ);
    TL2D.TLIncoh = reshape(Data(:,3), [TL2D.NumZ, TL2D.NumR]);
    TL2D.TLCoh = reshape(Data(:,4), [TL2D.NumZ, TL2D.NumR]);
    TL2D.Pressure = reshape(complex(Data(:,5), Data(:,6)), [TL2D.NumZ, TL2D.NumR]);
