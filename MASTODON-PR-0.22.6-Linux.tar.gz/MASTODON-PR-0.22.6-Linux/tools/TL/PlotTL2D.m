function TL2D = PlotTL2D(TLFile)
    TL2D = ReadTL2D(TLFile);

    figure;
    % Incoherent TL
    TL = TL2D.TLIncoh;
    TL(TL == 300) = NaN;
    imagesc(TL2D.Ranges,TL2D.Depths,TL);
    c = flipud(bone(512));
    %c = flipud(jet(512));  % Choose this to match Bellhop's plotting
    colormap(c);
    colorbar;
    set(colorbar, 'YDir', 'Reverse');
    title('MASTODON Incoherent TL');
    xlabel('Range (m)');
    ylabel('Depth (m)');
    
%     %mycolormap = [ zeros(1,3); jet(1000)];
%     mycolormap = [ jet(1000)];
%     colormap(mycolormap);
%     colorbar;

    figure;
    TL = TL2D.TLCoh;  % Coherent TL
    TL(TL == 300) = NaN;
    imagesc(TL2D.Ranges,TL2D.Depths,TL);
    title('Coherent TL');
    c = flipud(bone(512));
    %c = flipud(jet(512));  % Choose this to match Bellhop's plotting
    colormap(c);
    colorbar;
    h=colorbar; set(h, 'YDir', 'Reverse');
    xlabel('Range (m)');
    ylabel('Depth (m)');

    figure;
    imagesc(TL2D.Ranges,TL2D.Depths,abs(TL2D.Pressure));
    title('Pressure (Pa)');
    %colormap(mycolormap);
    colorbar;

    xlabel('Range (m)');
    ylabel('Depth (m)');
