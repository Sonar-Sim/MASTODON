function TL1D = ReadTL1D(TLFile)
    Data = dlmread(TLFile);
    % Skip header. Cannot specify the skip in dlmread, since it does not like
    % the delimiter being multiple spaces.
    Data = Data(2:end,:);

    TL1D.Ranges = Data(:,1);
    TL1D.Depths = Data(:,2);
    TL1D.TLIncoh = Data(:,3);
    TL1D.TLCoh = Data(:,4);
    TL1D.Pressure = complex(Data(:,5), Data(:,6));
