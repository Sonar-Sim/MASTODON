% Plots rays from a MASTODON ray trace text file
%
% Example usage:
%  PlotRayTrace('RayTrace.txt', 'exact', 0, 1, 2)
% This only plots rays that have one surface bounce and two bottom bounces
%  without skipping any rays
%
function PlotRayTrace(raytracefile, IncludeStr, Skip, SurfBounces, BtmBounces)
    %addpath('../GrabEnv Reader/');
    %GE = GrabEnvReader(grabenvfile);
    
    data = dlmread(raytracefile);
    ranges = data(:,1);
    [maxR, maxRpos] = max(ranges);
    ArrayLen = size(data,1);
    NumRays = floor(ArrayLen / maxRpos);
    MinZ = min(data(:,2));
    MaxZ = max(data(:,2));
    
    RayChangeIdx = [1];
    for n=2:ArrayLen
        if ranges(n) < ranges(n-1)
            RayChangeIdx = [RayChangeIdx n];
        end
    end
    
    % Add where the last ray ends
    if RayChangeIdx(end) ~= ArrayLen
        RayChangeIdx = [RayChangeIdx ArrayLen+1];
    end
    
    NumRays = length(RayChangeIdx) - 1;
    
%     iStart = 1;
%     iEnd = maxRpos;
%     Rays = [];

%     for i=1:NumRays
%         Rays = [Rays data(iStart:iEnd,:)];
%         iStart = iEnd+1;
%         iEnd = iEnd + maxRpos;
%     end
%     
%     Rays = reshape(Rays, [maxRpos 7 NumRays]);
%     clear data;
    % Now our last index of Rays is the ray number
    
    if (Skip < 0)
        Skip = 0;
    end
    CurRay = 0;
    
    figure;
    set(gca, 'Ydir', 'reverse');
    hold on;
    for n=1:NumRays
%        disp(i);
%         if strcmp(IncludeStr, 'exact')
%             if NumSurf ~= SurfBounces || NumBtm ~= BtmBounces
%                 continue;
%             end
%         elseif strcmp(IncludeStr, 'max')
%             if NumSurf > SurfBounces || NumBtm > BtmBounces
%                 continue;
%             end
%         %elseif IncludeStr == 'all'
%         end
%         r = Rays(:,1,i);
%         z = Rays(:,2,i);
        if RayChangeIdx(n+1) > length(data)+1
            break;
        end
        
        NumSurf = max(data(RayChangeIdx(n):RayChangeIdx(n+1)-1,3));
        NumBtm = max(data(RayChangeIdx(n):RayChangeIdx(n+1)-1,4));
        %disp([NumSurf, NumBtm]);
        
        if (NumSurf == 0 && NumBtm == 0)
            color = 'r';
        elseif (NumSurf == 1 && NumBtm == 0)
            color = 'g';
        elseif (NumSurf == 0 && NumBtm == 1)
            color = 'b';
        else
            color = 'k';
        end

        r = data(RayChangeIdx(n):RayChangeIdx(n+1)-1,1);
        z = data(RayChangeIdx(n):RayChangeIdx(n+1)-1,2);
        if (CurRay < Skip)
            CurRay = CurRay + 1;
        else
            plot(r,z,color);
            CurRay = 0;
        end
    end
    hold off;

    xlabel('Range (m)');
    ylabel('Depth (m)');
    title('MASTODON Ray Trace');
end
