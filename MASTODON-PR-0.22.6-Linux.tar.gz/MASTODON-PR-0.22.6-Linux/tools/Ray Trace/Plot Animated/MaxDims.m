function [maxR, maxZ] = MaxDims(rays)
    numRays = length(rays);
    maxR = 0;
    maxZ = 0;

    for nRay = 1 : numRays
        for nStep = 1 : length(rays(nRay).t)
            r = rays(nRay).r(nStep);
            if r > maxR
                maxR = r;
            end

            z = rays(nRay).z(nStep);
            if z > maxZ
                maxZ = z;
            end
        end
    end
end % MaxDims
