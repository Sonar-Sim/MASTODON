% Recreates part of MATLAB's Window Visualization Tool (wvtool)
function WindowPlot(Data)
    nfft = max(1024, length(Data));
    a = fft(Data, nfft);
    maxa = max(abs(a));
    x = fftshift(a);

    faxis = 0:2/nfft:1-2/nfft;
    faxis = [-fliplr(faxis) faxis];

    figure;
    subplot(1,2,1);
    plot(Data);
    xlabel('Samples');
    ylabel('Amplitude');
    title('Time domain');
    xlim([1,length(Data)]);
    ylim([0,max(Data)]);
    
    subplot(1,2,2);
    hold on;
    plot(faxis,20*log10(abs(x)/maxa));
    plot(-1:.1:1, -13*ones(length(-1:.1:1),1), 'r-.');  % Plot 13dB down
    xlim([0,1]);
    hold off;
    xlabel('Normalized frequency');
    ylabel('Magnitude (dB)');
    title('Frequency domain');
    