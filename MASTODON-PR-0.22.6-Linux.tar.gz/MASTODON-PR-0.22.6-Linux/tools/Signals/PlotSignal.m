function Signal = PlotSignal(SignalFile)
    Signal = ReadSignal(SignalFile);
    figure;
    plot(Signal.Times, real(Signal.Signal), 'DisplayName', 'Real part of signal');
    hold on;
    plot(Signal.Times, abs(Signal.Signal), 'DisplayName', 'Magnitude of signal');
    hold off;
    legend('show');
    xlabel('Time (s)');
    ylabel('Amplitude');
    title('MASTODON Signal');
