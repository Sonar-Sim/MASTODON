function P = Spectrum(data, fs, L)
% Computes and plots the spectrum of input data

    if (nargin < 3)  % n not set
        L = length(data);
    end
    
    P = fftshift(fft(data, L));
    
    figure;
    f = linspace(-fs/2, fs/2, L);
    plot(f/1000, abs(P));
    xlabel("Frequency (kHz)");
    title("FFT magnitude");

    return;
