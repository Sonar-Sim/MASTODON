% An example of using MATLAB to modify a configuration file and then run
% MASTODON with the modified file.

addpath("../../tools/libconfig-matlab");
lc = libconf.LibConf;
lc.load("../Ray Trace/MASTODON-Ray.cfg");

% Remove dependence on bathymetry file
lc.delete('environment.bottom.bathymetryfile');
lc.set('environment.bottom.dim', 0);
lc.set('environment.bottom.depth', 20);
lc.writeToFile("MASTODON-Ray-Modified.cfg");

% Remove the "-echo" to suppress output in the command window.
% This uses the strange filesep syntax to be able to run under both Windows and Linux.
run_command = ['..' filesep '..' filesep 'bin' filesep 'MASTODON MASTODON-Ray-Modified.cfg'];
[status,cmdout] = system(run_command, "-echo");
