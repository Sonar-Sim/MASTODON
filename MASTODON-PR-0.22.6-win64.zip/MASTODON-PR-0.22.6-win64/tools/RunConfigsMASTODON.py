# Runs any configuration files found in a folder

import glob, os, sys
import io, libconf
from pathlib import Path
import shutil
import logging


# Looks for the MASTODON_PATH environment variable. If that does not exist,
# just try using the MASTODON executable name, assuming it's on the main PATH.
def MastodonPath():
    try:
        return os.environ['MASTODON_PATH']
    except KeyError:
        return "MASTODON"
    
def MaxFileNameLength(fileList):
    max_len = -1
    for file in fileList:
        if len(file) > max_len:
            max_len = len(file)

    return max_len

class MastodonResults:
    def __init__(self, fileList, outputFile):
        self.maxFileNameLength = MaxFileNameLength(fileList)
        self.outputFile = outputFile
        FORMAT = '%(status)s %(file)-{0}s %(message)s'.format(self.maxFileNameLength)
        logging.basicConfig(filename=outputFile, encoding='utf-8', level=logging.INFO,format=FORMAT)
    
    def WriteResult(self, file, status, message):
        d = {'file': file, 'status':status}
        logging.info(message, extra=d)

def FindError(logFile, errorToken):
    with open(logFile, 'rt') as f:
        logLines = f.readlines()
    for line in logLines:
        if errorToken in line:
            return line
    return None

#
# Main
#

filesMax = 0  # No limit if 0

print(sys.argv)
print(len(sys.argv))
if len(sys.argv) != 2:
    print("Must provide folder name as argument")
    exit()

folder = os.path.abspath(sys.argv[1])
os.chdir(folder)

errorToken = 'Error!'
results = MastodonResults(glob.glob("*.cfg"), 'mastodon.log')

n = 1
for file in glob.glob("*.cfg"):
    print(file)

    # Make sure we're in the root config directory first
    os.chdir(folder)
    print("Folder: " + folder);

    # Prep subdirectory for running current config file
    newDir = Path(file).stem
    if os.path.exists(newDir):
        continue  # Skip this sim, since it already exists
    os.mkdir(newDir)
    fileToRun = Path(newDir)/file
    shutil.copy(file, fileToRun)

    os.chdir(newDir)
    
    with io.open(file) as f:
        config = libconf.load(f)

    mastPath = MastodonPath()
        
    outfile = config['simulation']['output_file']
    #outfile = config['output']['file']
    if os.path.exists(outfile):
        print(" * " + outfile + " already exists")
        continue

    os.system(mastPath + " \"" + file + "\"")# + " --silent")

    logFileName = config['log']['file']
    error = FindError(logFileName, errorToken)

    if error is None:
        results.WriteResult(file, 'COMPLETE', '')
    else:
        results.WriteResult(file, 'ERROR   ', error)
    
    n = n + 1
    if filesMax != 0 and n > filesMax:
        break
