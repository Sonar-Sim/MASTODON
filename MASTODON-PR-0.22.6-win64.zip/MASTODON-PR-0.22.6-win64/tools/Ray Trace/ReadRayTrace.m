function rays = ReadRayTrace(raytracefile)
    data = dlmread(raytracefile);
    ranges = data(:,1);

    rangeStarts = [1];
    rangeEnds = [];
    for n = 1 : length(ranges)-1
        if ranges(n+1) < ranges(n)
            rangeStarts = [rangeStarts n+1];
            rangeEnds = [rangeEnds n];
        end
    end
    rangeEnds = [rangeEnds length(ranges)];
    rangeLen = rangeEnds - rangeStarts;

    rays = [];
    for n = 1 : length(rangeStarts)
        curRay = [];
        for rl = 1 : rangeLen(n)
            curRayPos = rangeStarts(n) + rl;
            %disp(curRayPos);
            curRay.r(rl) = data(curRayPos,1);
            curRay.z(rl) = data(curRayPos,2);
            curRay.nSrf(rl) = data(curRayPos,3);
            curRay.nBtm(rl) = data(curRayPos,4);
            curRay.p(rl) = data(curRayPos,5);
            curRay.pCos(rl) = data(curRayPos,6);
            curRay.pSin(rl) = data(curRayPos,7);
            curRay.t(rl) = data(curRayPos,8);
            curRay.s(rl) = data(curRayPos,9);
        end

        rays = [rays curRay];
    end

end
