function dt = MeanTimeStep(rays)
    numRays = length(rays);
    dt = [];

    for n = 1 : numRays
        dt = [dt diff(rays(n).t)];
    end

    dt = mean(dt);
end
