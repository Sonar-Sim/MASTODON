% Plots rays from a MASTODON ray trace text file
%
% Example usage:
%  PlotRayTraceAnimated('RayTrace.txt')
%
function PlotRayTraceAnimated(raytracefile)
    addpath("..");  % Needed for ReadRayTrace.m

    rays = ReadRayTrace(raytracefile);
    dt = MeanTimeStep(rays);
    maxT = MaxTime(rays);
    [maxRange, maxDepth] = MaxDims(rays);

    figure;
    set(gca, 'Ydir', 'reverse');
    xlabel('Range (m)');
    ylabel('Depth (m)');
    title('MASTODON Ray Trace');

    %tmax = maxT / 4;
    numTime = floor(maxT / dt);

    for nt = 1 : numTime
        tmax = (nt-1) * dt;

        hold on;
        for nRay = 1 : length(rays)
            curRayEnd = 1;
            for nStep = 1 : length(rays(nRay).t)
                t = rays(nRay).t(nStep);
                if (t > tmax)
                    break
                end
                curRayEnd = nStep;
            end
    
            r = rays(nRay).r(1:curRayEnd);
            z = rays(nRay).z(1:curRayEnd);
            nBounces = rays(nRay).nBtm(nStep) + rays(nRay).nSrf(nStep);

            if (nBounces > 0)
                plot(r,z,'k');
            else
                plot(r,z,'b');
            end
            xlim([0,maxRange]);
            ylim([0,maxDepth]);
        end
        hold off;

        drawnow;
        pause(0.1);
    end

end
