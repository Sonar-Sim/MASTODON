function maxT = MaxTime(rays)
    numRays = length(rays);
    maxT = 0;

    for nRay = 1 : numRays
        for nStep = 1 : length(rays(nRay).t)
            t = rays(nRay).t(nStep);
            if t > maxT
                maxT = t;
            end
        end
    end

    disp(maxT);
end
