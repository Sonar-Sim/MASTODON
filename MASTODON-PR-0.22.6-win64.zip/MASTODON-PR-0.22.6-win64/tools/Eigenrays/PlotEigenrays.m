function PlotEigenrays(Filename)
    eig=ReadEigenrays(Filename);
    dr=max(diff(eig.r));  % Could be repeated positions

    figure;
    hold on;
    
    for n=1:length(eig.r)
        r1=eig.r(n);
        z1=eig.z(n);
        theta=eig.trgang(n)*pi/180;
        r2=r1-dr*cos(theta);
        z2=z1-dr*sin(theta);
        r=[r1 r2];
        z=[z1 z2];
        plot(r1,z1,'.');
        h=line(r,z);
        if (eig.nbtm(n) == 1 && eig.nsrf(n) == 0)
            h.Color = 'red';
        elseif (eig.nbtm(n) == 0 && eig.nsrf(n) == 1)
            h.Color = 'cyan';
        elseif (eig.nbtm(n) > 0 && eig.nsrf(n) > 0)
            h.Color = 'black';
        else
            h.Color='blue';
        end
    end
    
    hold off;
    ax=gca;
    ax.YDir='reverse';
    axis equal;
