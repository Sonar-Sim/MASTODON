import os
import sys
import json
import numpy as np
import matplotlib.pyplot as plt
from ReadBeamformed import readBeamFile

# From https://moonbooks.org/Articles/How-to-change-imshow-aspect-ratio-in-matplotlib-/
def forceAspect(ax,aspect):
    im = ax.get_images()
    extent = im[0].get_extent()
    ax.set_aspect(abs((extent[1]-extent[0])/(extent[3]-extent[2]))/aspect)


if len(sys.argv) == 1:
    #print('Must specify beamformed filename on command line')
    #exit()
    import tkinter as tk
    from tkinter import filedialog

    root = tk.Tk()
    root.withdraw()

    filename = filedialog.askopenfilename()
else:
    filename = sys.argv[1]

[x,y,data] = readBeamFile(filename)
data = np.abs(data)
data_max = np.max(data)
data = data / data_max
#data = np.clip(data, 0, 0.25)  # @todo: Remove - specific to one type of beamformed output

#
# Plot magnitude
#
fig = plt.figure()
ax = fig.add_subplot(111)

data = np.flipud(data)

#ax.imshow(np.log10(data), cmap = 'gray')#, extent=[-1,1,-10,10])
ax.imshow(data, extent = [x[0], x[-1], y[0], y[-1]], cmap = 'gray')#, extent=[-1,1,-10,10])
print(x[-1])
plt.title('Beamformed')
#forceAspect(ax,aspect=3.5)  # @todo: Remove - specific to one type of beamformed output
#fig.savefig("magnitude.png", bbox_inches='tight')
plt.show()
