function bf = ReadBeamformed(filename)
    [~, ~, ext] = fileparts(filename);
    if lower(ext) == ".json"
        bf = jsondecode(fileread(filename));
        bf.data = complex(bf.data(:,1:2:end), bf.data(:,2:2:end));
        bf.data = abs(bf.data);
        bf.data = bf.data / max(max(bf.data));
    elseif lower(ext) == ".hdf5" || lower(ext) == ".h5"
        % Test whether this is actually a stave data file. It's easy to
        % get the two mixed up.
        bTestSD = false;
        try
            testSD = h5read(filename, "/signal/num_samples");
            % This call just jumps into the catch!
            %error("The input file appears to be a stave data file, not a beamformed data file.");
            bTestSD = true;
        catch
        end
        if bTestSD
            error("The input file appears to be a stave data file, not a beamformed data file.");
        end

        %bf.data = squeeze(h5read(filename, '/Sonar/Sensor1/Data1/PingData'));
        bf.data = h5read(filename, '/Sonar/Sensor1/Data1/PingData');
        if isfield(bf.data, 'A')  % Wrote complex data
            bf.data = squeeze(bf.data.A + 1i * bf.data.B);
        else  % Magnitude only data here (and a separate /PingDataPhase)
            bf.data = squeeze(bf.data);
        end

        bHasCoords = false;
        try
            bf.x_coords = h5read(filename, '/Sonar/Sensor1/Data1/x_coords');
            bf.y_coords = h5read(filename, '/Sonar/Sensor1/Data1/y_coords');
            bHasCoords = true;  % This is a MASTODON file
        catch
            bf.x_coords = 1:size(bf.data,1);
            bf.y_coords = 1:size(bf.data,2);
        end

        %bf.data = bf.data / max(max(bf.data));
        % This doesn't exist in older HDF5 files
        try
            bf.beamformer = h5read(filename, '/Beamformer');
        catch
            bf.beamformer = "wk";  % Default
        end
    
        bHasMASTODONheader = false;
        try
            h5readatt(filename, "/", "MASTODON");
            bHasMASTODONheader = true;
        catch
        end
    
        % This logic gets a bit complicated. Older MASTODON outputs have the
        % coordinate entries but do not have the MASTODON header, and these do
        % not need to be transposed. Newer MASTODON outputs have to be
        % transposed but also match up with ASASIN's output style, which has to
        % be transposed as well.
        if (bHasCoords && bHasMASTODONheader) || ~bHasCoords
            bf.data = transpose(bf.data);
        end
    else
        error("Could not read beamformed file");
    end
    
    if ~isfield(bf, "beamformer")
        bf.beamformer = 'wk';
    end

    return;
