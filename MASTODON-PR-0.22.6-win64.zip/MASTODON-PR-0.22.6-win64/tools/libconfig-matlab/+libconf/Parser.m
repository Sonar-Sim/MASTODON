classdef Parser < handle
    %PARSER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        tokens
    end
    
    methods
        function obj = Parser(tokenstream)
            %PARSER Construct an instance of this class
            %   Detailed explanation goes here
            obj.tokens = tokenstream;
        end
        
        function result = parse(obj)
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here
            result = obj.configuration();
        end
        
        function result = configuration(obj)
            result = obj.setting_list_or_empty();
            if(~obj.tokens.finished())
                error(['Expected end of input but found ' obj.tokens.peek()]);
            end
        end
        
        function result = setting_list_or_empty(obj)
            result = containers.Map;
            while true
                [key, value] = obj.setting();
                if(isempty(key))
                    return;
                end
                result(key) = value;
            end
        end
        
        function [key, value] = setting(obj)
            key = []; value = [];
            name = obj.tokens.accept(libconf.TokenType.name);
            if(isempty(name))
                return;
            end
            
            obj.tokens.expect([libconf.TokenType.tcolon libconf.TokenType.equals]);
            
            value = obj.value();
            
            if(isempty(value))
                error('expected a value');
            end
            
            obj.tokens.accept([libconf.TokenType.semicolon libconf.TokenType.comma]);
            
            key = name.text;
        end
        
        function result = value(obj)
            result = {@obj.scalar_value @obj.array @obj.list @obj.group};
            result = obj.parse_any_of(result);
        end
        
        function result = string(obj)
            result = obj.tokens.accept(libconf.TokenType.string);
            if(isempty(result))
                return;
            end
            result = result.value(2:end-1);
            while true
                temp = obj.tokens.accept(libconf.TokenType.string);
                if(isempty(temp))
                    return;
                end
                result = [result ' ' temp.value(2:end-1)];
            end
        end
        
        function result = create_value_node(obj, type)
            result = obj.tokens.accept(type);
            if(~isempty(result))
                result = result.value;
            end
        end
        
        function result = float(obj)
            result = obj.create_value_node(libconf.TokenType.float);
        end
        function result = hex64(obj)
            result = obj.create_value_node(libconf.TokenType.hex64);
        end
        function result = hex(obj)
            result = obj.create_value_node(libconf.TokenType.hex);
        end
        function result = integer64(obj)
            result = obj.create_value_node(libconf.TokenType.integer64);
        end
        function result = integer(obj)
            result = obj.create_value_node(libconf.TokenType.integer);
        end
        function result = boolean(obj)
            result = obj.create_value_node(libconf.TokenType.boolean);
        end
        
        function result = scalar_value(obj)
            result = {@obj.string @obj.boolean @obj.integer @obj.float ...
                @obj.hex @obj.integer64 @obj.hex64};
            result = obj.parse_any_of(result);
        end
        
        function result = array(obj)
            result = obj.enclosed_block(libconf.TokenType.left_square,@obj.scalar_value_list_or_empty,libconf.TokenType.right_square);
        end
        
        function result = list(obj)
            result = obj.enclosed_block(libconf.TokenType.left_paren,@obj.value_list_or_empty,libconf.TokenType.right_paren);
        end
        
        function result = group(obj)
            result = obj.enclosed_block(libconf.TokenType.left_curl,@obj.setting_list_or_empty,libconf.TokenType.right_curl);
        end
        
        function result = enclosed_block(obj, start_token, nonterminal, end_token)
            result = [];
            token = obj.tokens.accept(start_token);
            if(isempty(token))
                return;
            end
            result = nonterminal();
            obj.tokens.expect(end_token);
            return;
        end
        
        function result = comma_separated_list_or_empty(obj, nonterminal)
            result = {};
            while true
                temp = nonterminal();
                if(isempty(temp))
                    return;
                end
                if(isempty(result))
                    result = {temp};
                else
                    result{end+1} = temp;
                end
                temp = obj.tokens.accept(libconf.TokenType.comma);
                if(isempty(temp))
                    return;
                end
            end
        end
        
        function result = parse_any_of(obj, nonterminals)
            for i = 1:length(nonterminals)
                func = nonterminals{i};
                result = func();
                if(~isempty(result))
                    return;
                end
            end
        end
        
        function result = scalar_value_list_or_empty(obj)
            result = obj.comma_separated_list_or_empty(@obj.scalar_value);
        end
        
        function result = value_list_or_empty(obj)
            result = obj.comma_separated_list_or_empty(@obj.value);
        end
    end
end

