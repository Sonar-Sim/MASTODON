classdef IntToken < libconf.Token
    methods
        function obj = IntToken(type, text, filename, row, column)
            obj@libconf.Token(type, text, filename, row, column);
            if(type == libconf.TokenType.hex || type == libconf.TokenType.hex64)
                obj.value = int32(hex2dec(text(3:end)));
            else
                obj.value = int32(str2num(text));
            end
        end
    end
end