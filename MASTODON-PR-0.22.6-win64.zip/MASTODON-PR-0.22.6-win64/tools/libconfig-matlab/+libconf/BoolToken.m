classdef BoolToken < libconf.Token
    methods
        function obj = BoolToken(type, text, filename, row, column)
           obj@libconf.Token(type, text, filename, row, column);
           obj.value = strcmp(text,'true');
        end
    end
end