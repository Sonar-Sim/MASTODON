function out = parse_config(filename,element)
    lc = libconf.LibConf;
    disp(['filename = ' filename]);
    config = lc.load(filename);
    disp(['element = ' element]);
    out = lc.lookup(config,element);
end

