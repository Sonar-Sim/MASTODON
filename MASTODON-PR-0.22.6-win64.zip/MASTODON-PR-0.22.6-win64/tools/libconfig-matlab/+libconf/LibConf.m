classdef LibConf < handle
    
    properties (Access = private)
        config
    end
    
    methods (Access = public)
        function obj = LibConf(filename)
            %LIBCONF creates a libConf object
            %   LIBCONF creates the object
            %   LIBCONF(FILENAME) creates the object and loads a file
            if(nargin == 1)
                obj.load(filename);
            else
                config = containers.Map;
            end
        end
        
        function load(obj,filename)
            %LOAD Loads a config file
            %   LOAD(FILENAME) loads the file FILENAME.
            if (~isa(filename,'char') && ~isa(filename,'string'))
                error('Argument is not type char');
            end
            if (~isfile(filename))
                error(['File not found: ' filename]);
            end
            ts = libconf.TokenStream;
            ts.from_file(filename);
            parser = libconf.Parser(ts);
            obj.config = parser.parse();
        end
        
        function dump(obj)
            %DUMP dumps the configuration to the command window
            fid = 1;
            obj.dump_dict(fid,obj.config,'');
        end
        
        function writeToFile(obj, outfile)
            %WRITETOFILE write the configuration to a file
            %   WRITETOFILE(OUTFILE) writes configuration to OUTFILE
            fid = fopen(outfile, 'w');
            obj.dump_dict(fid,obj.config,'');
            fclose(fid);
        end
        
        function result = lookup(obj,element)
            %LOOKUP fetches configuration value
            %   VALUE = LOOKUP(ELEMENT)
            %      ELEMENT - char type - 'field1.field2...'
            keys = strsplit(element,'.');
            result = obj.config;
            for key = keys
                result = result(key{1});
            end
        end
        
        function set(obj,element,value)
            %SET sets the value at a particular field
            %   SET(ELEMENT, VALUE) sets field ELEMENT to VALUE
            %      ELEMENT - char type - 'field1.field2...'
            keys = strsplit(element,'.');
            obj.config = obj.set_value(obj.config, keys, value);
        end

        function delete(obj,element)
            %DELETE removes a field
            keys = strsplit(element,'.');
            obj.config = obj.delete_key(obj.config, keys);
        end
    end
    
    methods (Access = private)    
        function dump_value(obj,fid,key,value,indent)
            line = indent;
            if(~isempty(key))
                line = [line key ' = '];
            end
            if(isa(value,'containers.Map'))
                line = [line '\n' indent '{\n'];
                fprintf(fid,line);
                obj.dump_dict(fid,value,[indent '    ']);
                line = [indent '}'];
                fprintf(fid,line);
            elseif(iscell(value))
                line = [line '\n' indent '(\n'];
                fprintf(fid,line);
                obj.dump_collection(fid,value,[indent '    ']);
                line = [indent ')'];
                fprintf(fid,line);
            else
                if(isa(value,'double'))
                    % Need to make sure its output floating point
                    if(~isinf(value) & floor(value) == value)
                        line = [line num2str(value) '.0'];
                    else
                        line = [line num2str(value)];
                    end
                    
                    
                elseif(isa(value,'int32'))
                    line = [line num2str(value)];
                elseif(isa(value,'logical'))
                    if(value)
                        line = [line 'true'];
                    else
                        line = [line 'false'];
                    end
                else
                    line = [line '"' value '"'];
                end
                fprintf(fid,line);
            end
            
        end
        
        function dump_collection(obj,fid,config,indent)
            for element = 1:length(config)
                obj.dump_value(fid,[],config{element},indent);
                if(element < length(config))
                    fprintf(fid,',\n');
                else
                    fprintf(fid,'\n');
                end
            end
        end
        
        function dump_dict(obj,fid,config,indent)
            for key = config.keys
                obj.dump_value(fid,key{1},config(key{1}),indent);
                fprintf(fid,';\n');
            end
        end

        function config = set_value(obj,config,keys,value)
            if (length(keys) > 1)
                if (config.isKey(keys{1}))
                    config(keys{1}) = obj.set_value(config(keys{1}), {keys{2:end}}, value);
                else
                    config(keys{1}) = containers.Map;
                    config(keys{1}) = obj.set_value(config(keys{1}), {keys{2:end}}, value);
                end
            else
                config(keys{1}) = value;
            end
        end
       
        function config = delete_key(obj,config,keys)
            if (length(keys) > 1)
                if(config.isKey(keys{1}))
                    config(keys{1}) = obj.delete_key(config(keys{1}), {keys{2:end}});
                else
                    config(keys{1}) = containers.Map;
                    config(keys{1}) = obj.delete_key(config(keys{1}), {keys{2:end}});
                end
            else
                remove(config, keys{1});
            end
        end
        
    end
end

