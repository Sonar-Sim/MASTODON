classdef StrToken < libconf.Token
    methods
        function obj = StrToken(type, text, filename, row, column)
           obj@libconf.Token(type, text, filename, row, column);
           obj.value = text;
        end
    end
end