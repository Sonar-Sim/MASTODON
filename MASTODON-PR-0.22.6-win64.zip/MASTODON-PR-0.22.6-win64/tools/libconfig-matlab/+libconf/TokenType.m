classdef TokenType
    enumeration
        float
        hex64
        hex
        integer64
        integer
        boolean
        string
        name
        left_curl
        right_curl
        left_paren
        right_paren
        left_square
        right_square
        comma
        semicolon
        equals
        tcolon
    end
end

