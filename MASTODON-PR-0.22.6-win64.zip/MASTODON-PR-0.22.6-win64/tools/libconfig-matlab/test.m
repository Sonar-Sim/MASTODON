filename = 'example.cfg';
outfile = 'testOut.cfg';
lc = libconf.LibConf;
lc.load(filename);
lc.dump;
lc.set('propagation.angle_inc',0.01);
disp(lc.lookup('propagation.angle_inc'));
lc.writeToFile(outfile);
