function ViewHeightMap(filename)
    [x,y,H] = ReadHeightMap(filename);
    figure;
    H = H';
    imagesc(x,y,flipud(H));  % Assumes opposite y-axis ordering
    set(gca, 'YDir', 'normal');
    title("Bathymetry");
    xlabel('Range (m)');
    ylabel('Cross Range (m)');
    axis equal;
    xlim([x(1), x(end)]);
    ylim([y(1), y(end)]);

    % @todo: This could really use a divergent colormap, such as the Vik
    % one from http://www.fabiocrameri.ch/colourmaps

    return;
