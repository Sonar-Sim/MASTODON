function stave = ReadStaveData(filename)
    [~,~,ext] = fileparts(filename);
    if (lower(ext) == ".json")
        stave = ReadStaveDataJson(filename);
    elseif (lower(ext) == ".hdf5" || lower(ext) == ".h5")
        stave = ReadStaveDataHdf5(filename);
    else
        stave = ReadStaveDataTxt(filename);
    end

    return;