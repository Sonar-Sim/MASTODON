function stave = ReadStaveDataTxt(filename)
    data = dlmread(filename);
    
    stave.nElem = data(2,1);
    stave.nTime = data(3,1);
    stave.nPings = data(4,1);
    stave.Fc = data(5,1);
    stave.BW = data(6,1);
    stave.Fs = data(7,1);
    stave.dy = data(8,1);
    stave.c = data(9,1);
    stave.bBasebanded = data(10,1);
    stave.SignalApplied = data(11,1);
    stave.rMin = data(12,1);
    
    data = data(13:end,:);
    data = complex(data(:,1), data(:,2));

    % This allows us to beamform with incomplete data
    data1 = zeros(stave.nPings*stave.nElem*stave.nTime,1);
    if length(data) ~= stave.nPings*stave.nElem*stave.nTime
        disp('Using incomplete stave data file!');
        data1(1:length(data)) = data;
        data = data1;
    end    
    
    data = reshape(data,[stave.nTime, stave.nPings*stave.nElem]);
    stave.data = data.';
    