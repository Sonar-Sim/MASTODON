function ViewReflMap(filename)
    fid = fopen(filename);

    %[a,count] = fscanf(fid, '%d', [1 inf]);
    %disp(a);
    %disp(count);
    %disp('test');
    %disp(fscanf(fid, '%10e'));

    % fscanf keeps grabbing the 0 from the next line
    s = fgetl(fid);
    num = sscanf(s, '%d');
    nx = num(1);
    ny = num(2);

    s = fgetl(fid);
    xvals = sscanf(s, '%e');
    s = fgetl(fid);
    yvals = sscanf(s, '%e');

    xmin = xvals(1);
    dx = xvals(2);

    ymin = yvals(1);
    dy = yvals(2);

    xmax = xmin + dx*nx;
    ymax = ymin + dy*ny;

    % Reads in all of the data. Could use dlmread instead.
    data = fscanf(fid, '%e');

    fclose(fid);

    figure;

    data = reshape(data, [nx, ny]);
    x = xmin+dx:dx:xmax;
    y = ymin+dy:dy:ymax;
    data = data';
    data = flipud(data);
    imagesc(x, y, data);
    colormap('pink');

    xlabel('Range');
    ylabel('Cross Range');

return;
