inFile = "Marius_Hills-Cropped.png";
outFile = "ReflMap-Marius_Hills-Cropped.txt";
xOffset = 0;
pixSize = 0.02;  % In meters - assuming pixels are square

im = imread(inFile);
im = im2gray(im);
im = double(im) / 255.0;
im = flipud(im);  % The image seems to be flipped vertically in example runs

fID = fopen(outFile, 'wt');

nX = size(im, 2);
nY = size(im, 1);
fprintf(fID, '%d %d\n', nX, nY);

xMin = xOffset;
dx = pixSize;
dy = pixSize;
yMin = -nY * dy / 2;
fprintf(fID, '%f %f\n%f %f\n', xMin, dx, yMin, dy);
fprintf(fID, '%f\n', im');

fclose(fID);
