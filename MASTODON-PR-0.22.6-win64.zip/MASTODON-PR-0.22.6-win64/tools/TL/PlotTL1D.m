function TL1D = PlotTL1D(TLFile)
    TL1D = ReadTL1D(TLFile);

    figure;
    hold on;
    plot(TL1D.Ranges, TL1D.TLIncoh, 'DisplayName', 'Incoherent TL');
    plot(TL1D.Ranges, TL1D.TLCoh, 'DisplayName', 'Coherent TL');
    legend('show');
    xlabel('Range (m)');
    ylabel('Level (dB)');
    title('PC SWAT TL 1D');
    hold off;
    
    figure;
    plot(TL1D.Ranges, abs(TL1D.Pressure));
    xlabel('Range (m)');
    ylabel('Pressure (Pa)');
    title('Pressure Magnitude');
