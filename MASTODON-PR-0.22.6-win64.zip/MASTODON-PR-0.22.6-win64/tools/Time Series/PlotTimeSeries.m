function PlotTimeSeries(filename)
    data = ReadTimeSeries(filename);
    dt = 1/data.Fs;
    t = (0:data.nTime-1)*dt;
    tMin = data.rMin / data.c;
    t = t + tMin;

    figure;
    plot(t,real(data.data));
    xlabel('Time (s)');
    ylabel('Pressure');
    title('Real');
    
    figure;
    plot(t,abs(data.data));
    xlabel('Time (s)');
    ylabel('Pressure');
    title('Magnitude');
