function data = ReadTimeSeries(filename)
    [~,~,ext] = fileparts(filename);
    if (lower(ext) == ".json")
        data = ReadTimeSeriesJson(filename);
    elseif (lower(ext) == ".hdf5" || lower(ext) == ".h5")
        data = ReadTimeSeriesHdf5(filename);
    else
        error("Unsupported filename extension");
    end
