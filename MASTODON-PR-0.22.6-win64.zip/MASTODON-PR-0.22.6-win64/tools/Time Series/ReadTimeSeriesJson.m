function data = ReadTimeSeriesJson(filename)
    data = jsondecode(fileread(filename));

    data.nTime = data.signal.num_samples;
    data.nElem = data.sonars.receiver.nelem;
    data.Fc = data.sonars.projector.frequency;
    data.BW = data.sonars.projector.bandwidth;
    data.Fs = data.signal.fs;
    data.rMin = data.signal.rangemin;
    data.c = data.environment.soundspeed;
    data.SignalApplied = data.signal.signal_applied;
    data.bBasebanded = data.signal.basebanded;
    data.proj_width = data.sonars.projector.width;
    data.recv_width = data.sonars.receiver.width;
    if isfield(data.sonars.receiver, "hor_spacing")
        data.hor_spacing = data.sonars.receiver.hor_spacing;
    else
        data.hor_spacing = data.recv_width;
    end

    if isfield(data.sonars.receiver, "nelem_hor")
        data.nElemHor = data.sonars.receiver.nelem_hor;
    end
    if isfield(data.sonars.receiver, "nelem_ver")
        data.nElemVer = data.sonars.receiver.nelem_ver;
    end
    
    if data.SignalApplied
        data.pulse_length = data.signal.pulse_length;
        signal = data.signal.signal;
        data.signal.signal = complex(signal(1:2:end), signal(2:2:end));
    end

    % Older JSON files used this format
    %data = stave.data;
    %data = complex(data(1:2:end), data(2:2:end));
    %data = reshape(data,[stave.nTime, stave.nPings*stave.nElem]);
    %stave.data = data.';
    
    if (isfield(data.signal, "data_format"))
        if (data.signal.data_format == "real")
            % Data only has a real part - use as is
        elseif (data.signal.data_format == "complex")
            % Data is interleaved real/imaginary doubles - convert to complex
            data.data = complex(data.data(:,1:2:end), data.data(:,2:2:end));
        else
            error("Invalid data format key");
        end
    else
        % Assume data is complex
        data.signal.data_format = "complex";
        data.data = complex(data.data(:,1:2:end), data.data(:,2:2:end));
    end
    
    if isfield(data, "motion")
        for n = 1:size(data.motion,1)
            m(n).x = data.motion(n,1);
            m(n).y = data.motion(n,2);
            m(n).z = data.motion(n,3);
            m(n).roll = data.motion(n,4);
            m(n).pitch = data.motion(n,5);
            m(n).yaw = data.motion(n,6);
            m(n).speed = data.motion(n,7);
            m(n).time = data.motion(n,8);
        end
        data.motion = m;
    end
        
%     data = dlmread(filename);
%     
%     stave.nElem = data(2,1);
%     stave.nTime = data(3,1);
%     stave.nPings = data(4,1);
%     stave.Fc = data(5,1);
%     stave.BW = data(6,1);
%     stave.Fs = data(7,1);
%     stave.dy = data(8,1);
%     stave.rMin = data(9,1);
%     
%     data = data(10:end,:);    
%     data = complex(data(:,1), data(:,2));
% 
%     % This allows us to beamform with incomplete data
%     data1 = zeros(stave.nPings*stave.nElem*stave.nTime,1);
%     if length(data) ~= stave.nPings*stave.nElem*stave.nTime
%         disp('Using incomplete stave data file!');
%         data1(1:length(data)) = data;
%         data = data1;
%     end    
%     
%     data = reshape(data,[stave.nTime, stave.nPings*stave.nElem]);
%     stave.data = data.';
%     