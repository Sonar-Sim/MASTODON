function delta = AlongResolutionSAS(D)
    delta = D / 2;
    return;
