function lambda = Wavelength(f, c)
    if nargin < 2
        c = 1500;
    end
    lambda = c / f;
    return;
