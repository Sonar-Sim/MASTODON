% Ground to slant range image conversion
function [x,y,DataGround] = SlantToGround(xVals, yVals, Data, altitude)
    if nargin < 4
        disp('Error - must provide all arguments!');
        return;
    end
    
    NumX = size(Data,2);
    NumY = size(Data,1);
    NewData = zeros(NumY, NumX);

    xS = sqrt(xVals.^2 - altitude^2);
    xSEqual = linspace(altitude, sqrt(xVals(end)^2 - altitude^2), NumX);
    
    for y = 1:NumY
        newInten = interp1(xS, Data(y,:), xSEqual);
        NewData(y,:) = newInten;
    end
    
    figure;
    imagesc(xSEqual, yVals, NewData);
    
    x = xSEqual;
    y = yVals;
    DataGround = NewData;
    
    return;