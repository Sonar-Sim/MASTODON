function [th,beam] = RectangularBeampattern(freq, elemLen, bFigures)
    if nargin < 3
        bFigures = false;
    end   
    
    n = 1801;  % Number of theta points to evaluate
    c = 1500;
    minTh = -pi/2;
    maxTh =  pi/2;

    k = 2*pi*freq / c;
    lambda = c / freq;
    L = elemLen;

    % Ratio of length to wavelength
    disp('Ratio: ' + string(L/lambda));

    th = linspace(minTh,maxTh,n);
    x = 0.5*k*L*sin(th);
    %x = pi*elemLen/lambda * sin(th);  % Alternative representation of the above
    %x = pi*elemLen/lambda * th;  % PC SWAT's
    b = sinc(x/pi);
    %b = b / max(abs(b));  % Normalize if necessary
    beam = b;

    th = th*180/pi;
    minTh = minTh*180/pi;
    maxTh = maxTh*180/pi;

    % When converting to decibels, these use 20*log10 instead of 10*log10,
    %  because this is the beam pattern of only one direction (transmit or
    %  receive). This is then the monostatic approximation, where the
    %  transmit and receive beam patterns are multiplied by each other.

    if bFigures
        figure;
        plot(th,abs(b).^2);
        xlabel('$$\theta^\circ$$','Interpreter','latex','FontSize',14);
        ylabel('$$|b(\theta)|$$','Interpreter','latex','FontSize',14);
        title('Beam pattern magnitude');
        xlim([minTh, maxTh]);

        figure;
        plot(th,angle(b));
        xlabel('$$\theta^\circ$$','Interpreter','latex','FontSize',14);
        ylabel('$$\textrm{arg}(b(\theta))$$','Interpreter','latex','FontSize',14);
        title('Beam pattern phase');
        xlim([minTh, maxTh]);

        figure;
        %plot(th, 10*log10(abs(b)));
        plot(th, 20*log10(abs(b)));
        ylim([-40,0]);
        %xlabel('Theta (degrees)');
        xlabel('$$\theta^\circ$$','Interpreter','latex','FontSize',14);
        ylabel('DI ($$\theta$$)','Interpreter','latex','FontSize',14);
        title('Directivity');
        xlim([minTh, maxTh]);

        figure;
        polarplot(th*pi/180, abs(b));  % MATLAB shows in degrees for radian input
        title('Beam pattern polar');

        figure;
        polarpattern(th, abs(b));
        title('Beam pattern polar pattern');

    end

    % Find the beamwidth using the -3dB points
    di = 20*log10(b);
    idx = find(di > -3);
    idxEnd = idx(end);  idxBegin = idx(1) - 2;
    idxMid = idx(1) + (idx(end)-idx(1))/2 - 2;  % Do not go to the 0
    disub = di(idxBegin:int32(idxMid));
    thsub = th(idxBegin:int32(idxMid));
    BW = 2 * abs(interp1(disub, thsub, -3));
    %BW = th(idx(end)) - th(idx(1));
    disp('Beamwidth calculated from graph: ' + string(BW));

    BWapprox = asin(lambda/L) * 180 / pi;
    disp('Beamwidth from approximation: ' + string(BWapprox));

    % https://ocw.mit.edu/courses/mechanical-engineering/2-011-introduction-to-ocean-science-and-engineering-spring-2006/readings/hw5_sonar_leonar.pdf
    BW3dB = 2*25.3*lambda/L;
    disp('Beamwidth from 2nd approximation: ' + string(BW3dB));

    % Hawkins thesis p.57
    BW3dB = 0.88*lambda/L * (180/pi);
    disp('Beamwidth from 3rd approximation: ' + string(BW3dB));
    disp('Null-null beamwidth: ' + string(2*asin(lambda/L) * 180/pi));
    
    return;
end