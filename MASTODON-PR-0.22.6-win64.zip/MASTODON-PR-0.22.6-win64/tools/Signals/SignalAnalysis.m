function SignalAnalysis(filename)
    sig = ReadSignal(filename);
    t = sig.Times;
    data = sig.Signal;
    
    tdiff = diff(t);
    Fs = 1/mean(tdiff);

    origlen = length(data);
    minlen = 4096;
    if length(data) < minlen
        data(length(data)+1:minlen) = 0.0;
        % Don't really need to expand t if we did this after the time
        %  series plotting. Keeping this just in case.
        dt = t(2)-t(1);
        addT = minlen-length(t);
        t(length(t)+1:minlen) = t(end) + (1:addT)*dt;
    end

    [~,name,ext] = fileparts(filename);
    fname = append(name, ext);
    
    figure;
    hold on;
    plot(t(1:origlen),real(data(1:origlen)));
    plot(t(1:origlen),imag(data(1:origlen)));
    legend('Real','Imaginary');
    hold off;
    xlabel('Time (s)');
    title(['Time series - ', fname]);
    
    figure;
    pspectrum(data,Fs,'spectrogram');
    title(['Spectrogram - ', fname]);

    figure;
    [pxx,f] = pwelch(data,500,300,500,Fs);
    plot(f/1000,10*log10(pxx));
    xlabel('Frequency (kHz)');
    title(['PSD - ', fname]);
    
    figure;
    L = length(data);
    %f = Fs*(-L/2+1:(L/2))/L;
    f = linspace(-Fs/2, Fs/2, length(data) * 4);
    plot(f/1000, abs(fftshift(fft(data, length(data)*4))));
    xlabel('Frequency (kHz)');
    title(['abs(FFT) - ', fname]);

%     % Useful for seeing the shape of the spectrum
%     [sp,fp,tp] = pspectrum(real(data),Fs,'spectrogram');
%     figure;
%     mesh(tp,fp,sp);
    