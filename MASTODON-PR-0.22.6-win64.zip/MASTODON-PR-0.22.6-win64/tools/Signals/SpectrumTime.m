function spec = SpectrumTime(data, fs, L)
% Computes and plots the spectrum of input data

    if (nargin < 3)  % n not set
        L = length(data) * 4;
    end
    
    total_elempings = size(data,1);
    f = linspace(-fs/2, fs/2, L);
    ping_num = 1:total_elempings;
    
    spec = zeros(total_elempings, L);
    for n = 1:total_elempings
        P = fftshift(fft(data(n,:), L));
        spec(n,:) = P;
    end
    
    figure;
    imagesc(f/1000, ping_num, abs(spec));
    xlabel('Frequency (kHz)');
    ylabel('Ping/element number');
    colormap(flipud(gray));
    set(gca, 'YDir', 'normal');

    return;
