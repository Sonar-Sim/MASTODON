function Signal = ReadSignal(SignalFile)
    Data = dlmread(SignalFile);
    Signal.Times = Data(:,1);
    Signal.Signal = complex(Data(:,2), Data(:,3));